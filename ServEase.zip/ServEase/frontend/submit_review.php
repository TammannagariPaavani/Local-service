<?php
session_start();
include("../backend/db.php"); // Keep this if your db.php is in ../backend/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $service_id = $_POST['service_id'] ?? '';
    $user_name = $_POST['user_name'] ?? '';
    $rating = $_POST['rating'] ?? '';
    $review_text = $_POST['review_text'] ?? '';

    if ($service_id && $user_name && $rating) {
        $stmt = $conn->prepare("INSERT INTO reviews (service_id, user_name, rating, review_text) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isis", $service_id, $user_name, $rating, $review_text);

        if ($stmt->execute()) {
            echo "✅ Review submitted successfully!";
        } else {
            echo "❌ Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "❌ Please fill all required fields.";
    }
}
?>
<?php
session_start();

// Only provider allowed
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'provider') {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Service</title>
    <style>
        body {
            font-family: Arial;
            background-color: #f4f6f9;
        }

        .container {
            width: 450px;
            margin: 60px auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h2 {
            text-align: center;
            color: #2c3e50;
        }

        input, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #2c3e50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #34495e;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Add New Service</h2>

    <form action="save-provider.php" method="POST">

        <input type="text" name="name" placeholder="Your Name" required>

        <!-- EMAIL VALIDATION -->
        <input type="email" name="email" placeholder="Email Address" required>

        <select name="type" required>
            <option value="">Select Service Type</option>
            <option value="plumber">Plumber</option>
            <option value="electrician">Electrician</option>
            <option value="carpenter">Carpenter</option>
            <option value="painter">Painter</option>
            <option value="tutor">Tutor</option>
        </select>

        <input type="text" name="city" placeholder="City" required>

        <input type="text" name="problem_type" placeholder="Problem Type" required>

        <!-- MOBILE VALIDATION -->
        <input type="text" 
       name="contact" 
       placeholder="Contact Number"
       maxlength="10"
       pattern="[0-9]{10}"
       oninput="this.value=this.value.replace(/[^0-9]/g,'')"
       title="Enter 10 digit mobile number only"
       required>

        <button type="submit">Submit Service</button>

    </form>
</div>

</body>
</html>
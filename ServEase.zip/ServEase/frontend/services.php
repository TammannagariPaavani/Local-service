<?php
session_start();
include("../backend/db.php");

$type = $_GET['type'] ?? '';
$type = trim($type);

if ($type == '') {
    die("Service type not selected.");
}

/* LOGIN CHECK */
$isLoggedIn = isset($_SESSION['user_id']);

/* HERO IMAGES */
$heroImages = [
    'plumber' => 'image/local.jpeg',
    'electrician' => 'image/electrician.jpg',
    'carpenter' => 'image/carpenter.jpeg',
    'painter' => 'image/painter.jpg',
    'tutor' => 'image/tutor.jpg',
    'mechanic' => 'image/mechanic.jpeg'
];

$heroImage = $heroImages[strtolower($type)] ?? 'image/local.jpeg';

/* ESCAPE TYPE */
$type_safe = $conn->real_escape_string($type);

/* FETCH PROVIDERS */
$providers = [];
$sql = "SELECT * FROM services 
        WHERE LOWER(TRIM(type)) = LOWER(TRIM('$type_safe'))  
        AND status='approved'";

$result = $conn->query($sql);

if (!$result) {
    die("Database Error: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
    $providers[] = $row;
}

/* FETCH PROBLEM TYPES */
$problemTypes = [];
$problemQuery = "SELECT DISTINCT problem_type 
                 FROM services 
                 WHERE LOWER(TRIM(type)) = LOWER(TRIM('$type_safe')) 
                 AND status='approved'";

$problemResult = $conn->query($problemQuery);

if ($problemResult) {
    while ($row = $problemResult->fetch_assoc()) {
        $problemTypes[] = $row['problem_type'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title><?php echo htmlspecialchars($type); ?> Services | ServEase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="../css/services.css">

<style>

.provider-card{
border:1px solid #ccc;
padding:15px;
margin:15px 0;
border-radius:8px;
background:#fff;
}

.call-btn{
padding:8px 14px;
color:white;
border-radius:4px;
display:inline-flex;
align-items:center;
gap:6px;
margin-top:8px;
font-weight:bold;
border:none;
cursor:pointer;
}

.available-btn{
background:green;
}

.service-form-box{
min-height:100vh;
display:flex;
justify-content:center;
align-items:center;
}

.service-card{
width:100%;
max-width:400px;
padding:20px;
background:#fff;
border-radius:8px;
}

.service-hero{
background-image:url('<?php echo $heroImage; ?>');
background-repeat:no-repeat;
background-position:center;
background-size:cover;
min-height:380px;
width:100%;
color:#fff;
text-align:center;
display:flex;
align-items:center;
justify-content:center;
position:relative;
border-radius:12px;
overflow:hidden;
box-shadow:0 20px 40px rgba(0,0,0,0.25);
}

.service-hero::after{
content:"";
position:absolute;
inset:0;
background:linear-gradient(to bottom,rgba(0,0,0,0.65),rgba(0,0,0,0.35),rgba(0,0,0,0.65));
}

.service-hero *{
position:relative;
z-index:1;
}

.review-form input,
.review-form select,
.review-form textarea{
width:100%;
padding:8px;
margin-bottom:10px;
border:1px solid #ccc;
border-radius:5px;
}

.review-form button{
background:#2c3e50;
color:white;
padding:10px;
width:100%;
border:none;
border-radius:5px;
font-weight:bold;
cursor:pointer;
}

</style>

</head>

<body class="<?php echo strtolower($type); ?>">

<header class="header">
<div class="container header-flex">
<h1 class="logo">ServEase</h1>
<a href="../index.html" class="back-btn">← Back to Home</a>
</div>
</header>

<section class="service-hero">
<div class="container">
<h2 class="service-title"><?php echo htmlspecialchars($type); ?> Services</h2>
<p>Verified professionals near your location</p>
</div>
</section>

<section class="container service-page">

<div class="service-layout">

<div class="service-form-box">

<div class="service-card">

<h3>Tell Us Your Requirement</h3>

<form id="serviceForm" class="service-form">

<label for="location">Your Location</label>

<select id="location" required>
<option value="">Choose Location</option>
<option>Raipur</option>
<option>Bhilai</option>
<option>Durg</option>
<option>Bilaspur</option>
<option>Bhopal</option>
<option>Indore</option>
</select>

<label for="problem">Problem Type</label>

<select id="problem" required>

<option value="">Select Problem Type</option>

<?php foreach($problemTypes as $problem): ?>

<option value="<?php echo htmlspecialchars($problem); ?>">
<?php echo htmlspecialchars($problem); ?>
</option>

<?php endforeach; ?>

</select>

<button type="submit">
Find <?php echo htmlspecialchars($type); ?>
</button>

</form>

</div>
</div>

<div class="provider-box" id="providerBox"></div>

</div>
</section>

<script>

let isLoggedIn = <?php echo $isLoggedIn ? 'true' : 'false'; ?>;

const providers = <?php echo json_encode($providers); ?>;

const form = document.getElementById("serviceForm");
const box = document.getElementById("providerBox");

function handleCall(contact){
    if(isLoggedIn){
        window.location.href = 'tel:' + contact;
    } else {
        alert('Please login first to call provider');
    }
}

form.addEventListener("submit", function(e){
    e.preventDefault();
    box.innerHTML="";

    const loc=document.getElementById("location").value;
    const problem=document.getElementById("problem").value;

    const filtered=providers.filter(c=>{
        return c.city &&
               c.problem_type &&
               c.city.trim().toLowerCase()===loc.trim().toLowerCase() &&
               c.problem_type.trim().toLowerCase()===problem.trim().toLowerCase();
    });

    if(filtered.length===0){
        box.innerHTML="<p>No professional found in this location.</p>";
        return;
    }

    filtered.forEach(c=>{

        let phoneDisplay=isLoggedIn
            ? `<p><strong>Phone:</strong> ${c.contact}</p>`
            : `<p><strong>Phone:</strong> 🔒 Login to view number</p>`;

        box.innerHTML += `
        <div class="provider-card">
            <p><strong>Name:</strong> ${c.name}</p>
            <p><strong>City:</strong> ${c.city}</p>
            <p><strong>Problem Type:</strong> ${c.problem_type}</p>
            ${phoneDisplay}
            <button class="call-btn available-btn" onclick="handleCall('${c.contact}')">
                📞 Call Now
            </button>

            <!-- Review Section -->
            <div class="review-section" style="margin-top:15px;">
                <h4 style="margin-bottom:10px;">⭐ Leave a Review</h4>
                <form action="submit_review.php" method="POST" class="review-form">
                    <input type="hidden" name="service_id" value="${c.id}">
                    <input type="text" name="user_name" placeholder="Your Name" required style="width:100%;padding:6px;margin-bottom:6px;border:1px solid #ccc;border-radius:4px;">
                    <select name="rating" required style="width:100%;padding:6px;margin-bottom:6px;border:1px solid #ccc;border-radius:4px;">
                        <option value="">Select Rating</option>
                        <option value="5">⭐⭐⭐⭐⭐ Excellent</option>
                        <option value="4">⭐⭐⭐⭐ Good</option>
                        <option value="3">⭐⭐⭐ Average</option>
                        <option value="2">⭐⭐ Poor</option>
                        <option value="1">⭐ Bad</option>
                    </select>
                    <textarea name="review_text" placeholder="Write your experience..." style="width:100%;padding:6px;margin-bottom:6px;border:1px solid #ccc;border-radius:4px;"></textarea>
                    <button type="submit" style="background:#2c3e50;color:white;padding:8px;width:100%;border:none;border-radius:5px;cursor:pointer;">Submit Review</button>
                </form>
            </div>
        </div>
        `;
    });

});

</script>

</body>
</html>
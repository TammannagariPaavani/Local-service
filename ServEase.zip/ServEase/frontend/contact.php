<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Contact Us | ServEase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/services.css">
<style>
.container {
    max-width: 900px;
    margin: 50px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2c3e50;
}
form p {
    margin: 10px 0 5px;
}
input, textarea {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 14px;
}
button {
    padding: 12px 25px;
    background: #2c3e50;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 16px;
}
button:hover {
    background: #1f2a38;
}
.back-btn {
    text-decoration: none;
    color: #2c3e50;
    font-weight: bold;
}
</style>
</head>
<body>

<header class="header">
<div class="container header-flex">
<h1 class="logo">ServEase</h1>
<a href="../index.html" class="back-btn">← Back to Home</a>
</div>
</header>

<div class="container">
<h2>Contact Us</h2>

<form action="contact_submit.php" method="POST">
    <p>Name:</p>
    <input type="text" name="name" placeholder="Your Name" required>

    <p>Email:</p>
    <input type="email" name="email" placeholder="Your Email" required>

    <p>Message:</p>
    <textarea name="message" rows="6" placeholder="Write your message here..." required></textarea>

    <button type="submit" name="submit">Send Message</button>
</form>
</div>

</body>
</html>
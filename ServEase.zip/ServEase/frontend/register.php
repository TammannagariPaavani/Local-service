<?php
session_start();
include("../backend/db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $check = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($check);

    if ($result->num_rows > 0) {
        $message = "Email already registered!";
    } else {

        $sql = "INSERT INTO users (name, email, password, role) 
                VALUES ('$name', '$email', '$hashedPassword', '$role')";

        if ($conn->query($sql) === TRUE) {
            $message = "Registration Successful! You can login now.";
        } else {
            $message = "Error: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>

    <style>
        body {
            background-color: #dae7fb;
            font-family: Arial, sans-serif;
        }

        .form-section {
            max-width: 400px;
            margin: 80px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            text-align: center;
        }

        .form-section h2 {
            margin-bottom: 20px;
            color: #032b55;
        }

        .form-section input, 
        .form-section select {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .form-section button {
            width: 100%;
            padding: 12px;
            background-color: #032b55;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
        }

        .form-section button:hover {
            background-color: #ffc107;
            color: #032b55;
        }

        .message {
            margin-bottom: 10px;
            font-weight: bold;
        }

        .success { color: green; }
        .error { color: red; }

        .login-link {
            margin-top: 15px;
            display: block;
        }

        /* Hide fake fields */
        .hidden-field {
            position: absolute;
            left: -9999px;
        }
    </style>
</head>

<body>

<div class="form-section">
    <h2>Create Account</h2>

    <?php if($message != "") { ?>
        <p class="message <?php echo (strpos($message, 'Successful') !== false) ? 'success' : 'error'; ?>">
            <?php echo $message; ?>
        </p>
    <?php } ?>

    <!-- Autofill Disabled -->
    <form method="POST" autocomplete="off">

        <!-- Fake fields to trick browser -->
        <input type="text" class="hidden-field" name="fakeuser">
        <input type="password" class="hidden-field" name="fakepassword">

        <input type="text" name="username" placeholder="Full Name" required autocomplete="off">
        <input type="email" name="email" placeholder="Email Address" required autocomplete="off">
        <input type="password" name="password" placeholder="Password" required autocomplete="new-password">

        <select name="role" required>
            <option value="">Register As</option>
            <option value="user">User</option>
            <option value="provider">Service Provider</option>
        </select>

        <button type="submit">Register</button>
    </form>

    <a href="login.php" class="login-link">Already have an account? Login here</a>
</div>

</body>
</html>
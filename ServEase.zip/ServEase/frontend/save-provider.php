<?php
session_start();
include("../backend/db.php");

// Provider login check
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'provider') {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (
        empty($_POST['name']) ||
        empty($_POST['type']) ||
        empty($_POST['city']) ||
        empty($_POST['problem_type']) ||
        empty($_POST['contact'])
    ) {
        die("All fields are required.");
    }

    $name = $_POST['name'];
    $type = $_POST['type'];
    $city = $_POST['city'];
    $problem = $_POST['problem_type'];
    $contact = $_POST['contact'];
    $provider_id = $_SESSION['user_id'];

    // Correct query (NO id column)
    $stmt = $conn->prepare("INSERT INTO services 
        (name, type, city, problem_type, contact, status, provider_id)
        VALUES (?, ?, ?, ?, ?, 'pending', ?)");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssi", $name, $type, $city, $problem, $contact, $provider_id);

    if ($stmt->execute()) {
        header("Location: provider-dashboard.php?success=1");
        exit();
    } else {
        die("Insert failed: " . $stmt->error);
    }
}
?>
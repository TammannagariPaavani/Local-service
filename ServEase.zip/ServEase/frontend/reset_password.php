<?php
include("../backend/db.php");

if (!isset($_GET['token'])) {
    die("Invalid request!");
}

$token = $_GET['token'];

$stmt = $conn->prepare("SELECT * FROM users WHERE reset_token=? AND token_expiry > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("Invalid or Expired Token!");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $newPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $update = $conn->prepare("UPDATE users SET password=?, reset_token=NULL, token_expiry=NULL WHERE reset_token=?");
    $update->bind_param("ss", $newPassword, $token);
    $update->execute();

    echo "Password Updated Successfully!";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
</head>
<body>

<h2>Reset Password</h2>

<form method="POST">
    <input type="password" name="password" placeholder="Enter new password" required>
    <button type="submit">Update Password</button>
</form>

</body>
</html>
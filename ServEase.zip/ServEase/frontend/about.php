<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>About Us | ServEase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/services.css">
<style>
.container {
    max-width: 900px;
    margin: 50px auto;
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
}
h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #2c3e50;
}
p {
    font-size: 16px;
    line-height: 1.7;
    margin: 15px 0;
}
.header-flex {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.back-btn {
    text-decoration: none;
    color: #2c3e50;
    font-weight: bold;
}
</style>
</head>
<body>

<header class="header">
<div class="container header-flex">
<h1 class="logo">ServEase</h1>
<a href="../index.html" class="back-btn">← Back to Home</a>
</div>
</header>

<div class="container">
<h2>About ServEase</h2>
<p>ServEase is your one-stop platform for hiring professional service providers near you. Whether you need plumbing, carpentry, electrical work, or cleaning services, ServEase connects you with verified providers who can get the job done efficiently and reliably.</p>
<p>Our mission is to make local services easily accessible for everyone while ensuring quality and transparency. Both users and providers can create profiles, manage services, and maintain trustworthy connections through our platform.</p>
<p>At ServEase, we value convenience, professionalism, and customer satisfaction. Our platform is designed to be user-friendly and responsive, ensuring a smooth experience across devices.</p>
</div>

</body>
</html>
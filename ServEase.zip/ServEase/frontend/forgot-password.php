<?php
include("../backend/db.php");

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = trim($_POST['email']);

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "<div class='error'>Please enter a valid email!</div>";
    } else {

        $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {

            $token = bin2hex(random_bytes(32));
            $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));

            $update = $conn->prepare("UPDATE users SET reset_token=?, token_expiry=? WHERE email=?");
            $update->bind_param("sss", $token, $expiry, $email);

            if ($update->execute()) {

                // IMPORTANT: change this path if folder name is different
                $resetLink = "http://localhost/servease/frontend/reset_password.php?token=" . $token;

                $message = "<div class='success'>
                            Reset Link Generated:<br>
                            <a href='$resetLink'>$resetLink</a>
                            </div>";
            } else {
                $message = "<div class='error'>Failed to update token!</div>";
            }

        } else {
            $message = "<div class='error'>Email not found!</div>";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Forgot Password</title>

<style>
body {
    background: linear-gradient(135deg, #bedff0, #ffffff);
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.container {
    max-width: 400px;
    margin: 100px auto;
    background: #ffffff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.2);
    text-align: center;
}

h2 {
    margin-bottom: 20px;
    color: #032b55;
}

input {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border-radius: 6px;
    border: 1px solid #ccc;
}

button {
    width: 100%;
    padding: 12px;
    background-color: #032b55;
    color: white;
    border: none;
    border-radius: 6px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background-color: #ffc107;
    color: #032b55;
}

.success {
    color: green;
    font-weight: bold;
}

.error {
    color: red;
    font-weight: bold;
}

a {
    text-decoration: none;
    color: #032b55;
    font-weight: bold;
}

a:hover {
    text-decoration: underline;
}
</style>

</head>
<body>

<div class="container">
    <h2>Forgot Password</h2>

    <form method="POST">
        <input type="email" name="email" placeholder="Enter your email" required>
        <button type="submit">Send Reset Link</button>
    </form>

    <br>
    <?php echo $message; ?>

    <br><br>
    <a href="login.php">Back to Login</a>
</div>

</body>
</html>
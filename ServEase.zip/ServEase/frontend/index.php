<?php
session_start(); // Start session

// Include database connection
include("../backend/db.php");

// Check if database connection exists
if (!isset($conn)) {
    die("Database connection failed.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Local Services | ServEase</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../css/index.css">
</head>
<body>

<header class="header">
    <div class="logo-box">
        <img src="image/logo.png" alt="ServEase Logo" class="logo-icon">
    </div>

    <nav class="nav">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>

        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="profile.php" id="profileLink">Profile</a>
            <a href="../frontend/logout.php" id="logoutLink">Logout</a>
        <?php else: ?>
            <a href="login.php" id="loginLink">Login</a>
            <a href="register.php" id="registerLink">Register</a>
        <?php endif; ?>
    </nav>
</header>

<section class="hero">
    <div class="slider">
        <img src="image/painter.jpg" class="slide active" alt="Painter">
        <img src="image/electrician.jpg" class="slide" alt="Electrician">
        <img src="image/tutor.jpg" class="slide" alt="Tutor">
        <img src="image/mechanic.jpg" class="slide" alt="Mechanic">
    </div>

    <div class="container hero-content">
        <h2>Find Trusted Services Near You</h2>
        <p>Plumbers, Electricians, Painters, Carpenters, Tutors & More</p>

        <form action="../backend/search.php" method="GET" class="search-form">
            <input type="text" name="city" placeholder="Enter City" required>
            <input type="text" name="service" placeholder="Enter Service" required>
            <button type="submit">Search</button>
        </form>

        <?php if(isset($_SESSION['user_id'])): ?>
            <p style="color:green; margin-top:10px;">You are logged in!</p>
        <?php else: ?>
            <p style="color:red; margin-top:10px;">You are not logged in.</p>
        <?php endif; ?>
    </div>
</section>

<section class="services">
    <div class="container">
        <h2>Popular Services</h2>
        <div class="service-cards">
<?php
$static_services = [
    ["type" => "Plumber", "desc" => "Fix leaks, taps, pipes, and plumbing issues."],
    ["type" => "Carpenter", "desc" => "Residential and commercial carpentry solutions."],
    ["type" => "Painter", "desc" => "Interior and exterior painting services."],
    ["type" => "Tutor", "desc" => "Home tutoring for all subjects."],
    ["type" => "Mechanic", "desc" => "Car and bike repair services."],
    ["type" => "Electrician", "desc" => "Electrical wiring and repairs."]
];

foreach($static_services as $s) {
    echo '
    <a href="services.php?type='.htmlspecialchars($s["type"]).'" class="card-link">
        <div class="card">
            <h3>'.htmlspecialchars($s["type"]).'</h3>
            <p>'.htmlspecialchars($s["desc"]).'</p>
        </div>
    </a>
    ';
}
?>
        </div>
    </div>
</section>

<footer class="footer">
    <p>© 2026 Local Services. All rights reserved.</p>
</footer>

<script src="../js/main.js"></script>

<script>
let slides = document.querySelectorAll('.slide');
let currentSlide = 0;

function nextSlide() {
    if(slides.length > 0) {
        slides[currentSlide].classList.remove('active');
        currentSlide = (currentSlide + 1) % slides.length;
        slides[currentSlide].classList.add('active');
    }
}
setInterval(nextSlide, 4000);
</script>

</body>
</html>
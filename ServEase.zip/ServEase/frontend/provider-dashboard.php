<?php
session_start();
include("../backend/db.php");

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'provider') {
    header("Location: login.php");
    exit();
}

$provider_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM services WHERE provider_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $provider_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html>
<head>
<title>Provider Dashboard</title>

<style>
body{
    font-family: Arial, sans-serif;
    background:#f4f6f9;
    margin:0;
}

header{
    background:#2c3e50;
    color:white;
    padding:15px 40px;
    display:flex;
    justify-content:space-between;
}

.container{
    width:90%;
    margin:30px auto;
}

.btn{
    padding:10px 20px;
    background:#2c3e50;
    color:white;
    text-decoration:none;
    border-radius:5px;
}

table{
    width:100%;
    border-collapse:collapse;
    background:white;
    margin-top:20px;
}

th, td{
    padding:12px;
    border-bottom:1px solid #ddd;
    text-align:center;
}

th{
    background:#2c3e50;
    color:white;
}

.status-pending{ color:orange; font-weight:bold; }
.status-approved{ color:green; font-weight:bold; }
.status-rejected{ color:red; font-weight:bold; }

.card{
    background:white;
    padding:20px;
    border-radius:8px;
    box-shadow:0 2px 5px rgba(0,0,0,0.1);
}
</style>
</head>

<body>

<header>
    <h2>Provider Dashboard</h2>
    <a href="logout.php" style="color:#ffc107;">Logout</a>
</header>

<div class="container">

<div class="card">
    <a href="add-service.php" class="btn">➕ Add New Service</a>

    <table>
        <tr>
            <th>Service</th>
            <th>City</th>
            <th>Problem</th>
            <th>Contact</th>
            <th>Status</th>
        </tr>

        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($row['type']); ?></td>
            <td><?php echo htmlspecialchars($row['city']); ?></td>
            <td><?php echo htmlspecialchars($row['problem_type']); ?></td>
            <td><?php echo htmlspecialchars($row['contact']); ?></td>
            <td class="status-<?php echo $row['status']; ?>">
                <?php echo ucfirst($row['status']); ?>
            </td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>

</div>
</body>
</html>
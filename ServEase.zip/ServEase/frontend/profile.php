<?php
session_start();
include("../backend/db.php");

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Fetch user details
$stmt = $conn->prepare("SELECT * FROM users WHERE id=? AND role='user'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    die("User not found or not a normal user.");
}

/* UPDATE NAME + EMAIL */
if (isset($_POST['update_profile'])) {

    $new_name = trim($_POST['name']);
    $new_email = trim($_POST['email']);

    if ($new_name == "" || $new_email == "") {
        $error = "Name and Email cannot be empty.";
    }
    elseif (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    }
    else {

        $update_stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
        $update_stmt->bind_param("ssi", $new_name, $new_email, $user_id);

        if ($update_stmt->execute()) {
            $success = "Profile updated successfully!";
            $user['name'] = $new_name;
            $user['email'] = $new_email;
        } else {
            $error = "Failed to update profile.";
        }
    }
}

/* PHONE UPDATE */
if (isset($_POST['update_phone'])) {

    $new_phone = trim($_POST['phone']);

    if (!preg_match('/^[0-9]{10}$/', $new_phone)) {
        $error = "Phone number must be 10 digits.";
    }
    else {

        $update_stmt = $conn->prepare("UPDATE users SET phone=? WHERE id=?");
        $update_stmt->bind_param("si", $new_phone, $user_id);

        if ($update_stmt->execute()) {
            $success = "Phone updated successfully!";
            $user['phone'] = $new_phone;
        } else {
            $error = "Failed to update phone.";
        }
    }
}

/* DELETE REVIEW */
if (isset($_GET['delete_review'])) {

    $review_id = intval($_GET['delete_review']);

    $del_stmt = $conn->prepare("DELETE FROM reviews WHERE id=?");
    $del_stmt->bind_param("i", $review_id);
    $del_stmt->execute();

    header("Location: user-profile.php");
    exit;
}

/* FETCH REVIEWS */
$reviews_stmt = $conn->prepare("SELECT r.*, s.name as service_name FROM reviews r 
                                JOIN services s ON r.service_id = s.id 
                                WHERE r.user_name = ?");
$reviews_stmt->bind_param("s", $user['name']);
$reviews_stmt->execute();
$reviews_result = $reviews_stmt->get_result();
$reviews = $reviews_result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<title>User Profile | ServEase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>

body{
font-family:Arial;
background:#f4f6f9;
}

.profile-container{
max-width:800px;
margin:30px auto;
background:#fff;
padding:20px;
border-radius:12px;
box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

.profile-header{
display:flex;
align-items:center;
justify-content:space-between;
margin-bottom:20px;
}

.avatar{
width:60px;
height:60px;
border-radius:50%;
background:#2c3e50;
color:white;
display:flex;
align-items:center;
justify-content:center;
font-size:25px;
font-weight:bold;
}

.review-card{
border:1px solid #ccc;
padding:15px;
margin:10px 0;
border-radius:8px;
background:#f9f9f9;
}

input{
padding:6px 10px;
border-radius:5px;
border:1px solid #ccc;
margin:3px;
}

button{
padding:6px 10px;
background:#2c3e50;
color:white;
border:none;
border-radius:5px;
cursor:pointer;
}

.delete-btn{
background:red;
}

.success{color:green;}
.error{color:red;}

</style>

</head>

<body>

<div class="profile-container">

<div class="profile-header">

<div style="display:flex;align-items:center;gap:10px;">

<div class="avatar">
<?= strtoupper(substr($user['name'],0,1)); ?>
</div>

<h2><?= htmlspecialchars($user['name']); ?></h2>

</div>

<a href="../logout.php" style="background:red;color:white;padding:8px 15px;text-decoration:none;border-radius:5px;">Logout</a>

</div>

<?php if(isset($success)) echo "<p class='success'>$success</p>"; ?>
<?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>

<!-- EDIT NAME EMAIL -->

<form method="POST">

<p>
<strong>Name:</strong>
<input type="text" name="name" value="<?= htmlspecialchars($user['name']); ?>">
</p>

<p>
<strong>Email:</strong>
<input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>">
</p>

<button type="submit" name="update_profile">Update Profile</button>

</form>

<br>

<!-- PHONE UPDATE -->

<form method="POST">

<p>
<strong>Phone:</strong>

<input type="text"
name="phone"
value="<?= htmlspecialchars($user['phone'] ?? '') ?>"
maxlength="10"
pattern="[0-9]{10}"
oninput="this.value=this.value.replace(/[^0-9]/g,'')"
placeholder="Contact Number"
required>

<button type="submit" name="update_phone">Update</button>

</p>

</form>

<hr>

<h3>Your Reviews</h3>

<?php if(count($reviews)>0): ?>

<?php foreach($reviews as $rev): ?>

<div class="review-card">

<p><strong>Service:</strong> <?= htmlspecialchars($rev['service_name']); ?></p>

<p><strong>Rating:</strong> <?= htmlspecialchars($rev['rating']); ?> ⭐</p>

<p><strong>Review:</strong> <?= htmlspecialchars($rev['review_text']); ?></p>

<p><small><?= htmlspecialchars($rev['created_at']); ?></small></p>

<a class="delete-btn" href="?delete_review=<?= $rev['id']; ?>" 
onclick="return confirm('Delete this review?')" 
style="padding:5px 10px;color:white;text-decoration:none;border-radius:5px;">
Delete
</a>

</div>

<?php endforeach; ?>

<?php else: ?>

<p>No reviews submitted yet.</p>

<?php endif; ?>

</div>

</body>
</html>
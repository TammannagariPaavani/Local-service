<?php
session_start();
include("../backend/db.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows == 1) {

        $row = $result->fetch_assoc();

        if (password_verify($password, $row['password'])) {

            // Store session
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['name'];
            $_SESSION['role'] = $row['role'];

            // Only User & Provider Redirect
            if ($row['role'] == 'provider') {
                header("Location: provider-dashboard.php");
                exit();
            }
            elseif ($row['role'] == 'user') {
                header("Location: index.php");
                exit();
            }
            else {
                $error = "Invalid role!";
            }

        } else {
            $error = "Wrong Password!";
        }

    } else {
        $error = "Email not found!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>

    <style>
        body {
            background-color: #cde1fe;
            font-family: Arial, sans-serif;
        }

        .form-section {
            max-width: 400px;
            margin: 80px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            text-align: center;
        }

        .form-section h2 {
            margin-bottom: 20px;
            color: #032b55;
        }

        .form-section input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .form-section button {
            width: 100%;
            padding: 12px;
            background-color: #032b55;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
        }

        .form-section button:hover {
            background-color: #ffc107;
            color: #032b55;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        .register-link {
            margin-top: 15px;
            display: block;
        }

        .hidden-field {
            position: absolute;
            left: -9999px;
        }
    </style>
</head>
<body>

<div class="form-section">
    <h2>Login</h2>

    <?php if($error != "") { ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>

    <form method="POST" autocomplete="off">

        <input type="text" class="hidden-field">
        <input type="password" class="hidden-field">

        <input type="email" name="email" placeholder="Enter Email" required autocomplete="off">
        <input type="password" name="password" placeholder="Enter Password" required autocomplete="new-password">

        <button type="submit">Login</button>
    </form>
    <a href="forgot-password.php" class="register-link" ...>Forgot Password?</a>

    <a href="register.php" class="register-link">Don't have an account? Register Here</a>

</div>

</body>
</html>
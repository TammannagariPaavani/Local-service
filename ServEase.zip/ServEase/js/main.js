/* jshint esversion: 6 */
// Simple slider JS
let slides = document.querySelectorAll('.slide');
let current = 0;

function slider() {
    slides.forEach(slide => slide.classList.remove('active'));
    current = (current + 1) % slides.length;
    slides[current].classList.add('active');
}

setInterval(slider, 4000); // 4s
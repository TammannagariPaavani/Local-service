<?php
include("db.php");

$city = $_GET['city'] ?? '';
$service = $_GET['service'] ?? '';

$sql = "SELECT * FROM services WHERE city LIKE ? AND type LIKE ?";
$stmt = $conn->prepare($sql);
$searchCity = "%$city%";
$searchService = "%$service%";
$stmt->bind_param("ss", $searchCity, $searchService);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div>
                <h3>{$row['name']}</h3>
                <p>Type: {$row['type']}</p>
                <p>City: {$row['city']}</p>
                <p>Contact: {$row['contact']}</p>
                <p>{$row['description']}</p>
              </div><hr>";
    }
} else {
    echo "No services found.";
}
?>
<?php
include("../backend/db.php");

if(isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM services WHERE id=$id";

    if($conn->query($sql) === TRUE) {
        header("Location: admin-dashboard.php");
        exit();
    } else {
        echo "Error deleting record";
    }
} else {
    echo "Invalid ID";
}
?>
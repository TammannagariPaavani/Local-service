<?php
session_start();
include("../backend/db.php");

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin-login.php");
    exit();
}

if (!isset($_GET['id'])) {
    die("Invalid request!");
}

$service_id = intval($_GET['id']);

$stmt = $conn->prepare("UPDATE services SET status='approved' WHERE id=?");
$stmt->bind_param("i", $service_id);

if ($stmt->execute()) {
    $stmt->close();
    header("Location: admin-dashboard.php");
    exit();
} else {
    die("Error updating service status.");
}
?>
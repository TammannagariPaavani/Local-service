<?php
session_start();

// Hardcoded admin credentials
$email = $_POST['adminEmailField'] ?? '';
$password = $_POST['adminPasswordField'] ?? '';        // new password
$error = "";

// Login check
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['adminEmailField'] ?? '';
    $password = $_POST['adminPasswordField'] ?? '';

    if ($email === "paavani@gmail.com" && $password === "paavani2004") {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin-dashboard.php"); // Redirect to dashboard
        exit();
    } else {
        $error = "Invalid credentials!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login | ServEase</title>
<style>
    body {
        background-color: #cde1fe;
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: flex-start; /* top align for tall form */
        min-height: 100vh;
        padding-top: 60px; /* give space from top */
        margin: 0;
    }

    .login-card {
        width: 400px;
        max-width: 90%;
        padding: 60px 40px; /* extra top/bottom padding for height */
        background: #ffffff;
        border-radius: 16px;
        box-shadow: 0 12px 30px rgba(0,0,0,0.15);
        text-align: center;
    }

    .login-card h3 {
        margin-bottom: 40px;
        font-size: 28px;
        color: #032b55;
    }

    .login-card input {
        width: 100%;
        padding: 10px; /* taller input */
        margin: 25px 0; /* more vertical spacing */
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
    }

    .login-card button {
        width: 100%;
        padding: 22px; /* taller button */
        background-color: #032b55;
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        font-size: 18px;
        font-weight: bold;
        margin-top: 30px;
        transition: 0.3s;
    }

    .login-card button:hover {
        background-color: #ffc107;
        color: #032b55;
    }

    .error {
        color: red;
        margin-bottom: 20px;
        font-weight: bold;
    }
</style>
</head>
<body>

<div class="login-card">
    <h3>Admin Login</h3>
    <?php if($error): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>
    <form method="POST" autocomplete="off">
    <input type="email" name="adminEmailField" placeholder="Enter your email" required autocomplete="off">
<input type="password" name="adminPasswordField" placeholder="Enter your password" required autocomplete="new-password">
    <button type="submit">Login</button>
</form>
</div>


</body>
</html>
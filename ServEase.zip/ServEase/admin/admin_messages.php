<?php
session_start();
include("../backend/db.php");

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit;
}

// Fetch all messages
$result = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin - Contact Messages | ServEase</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/services.css">
<style>
.container {
    max-width: 1000px;
    margin: 50px auto;
    background:#fff;
    padding:20px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.15);
}
table {
    width:100%;
    border-collapse: collapse;
}
th, td {
    border:1px solid #ccc;
    padding:10px;
    text-align:left;
}
th {
    background:#2c3e50;
    color:white;
}
tr:nth-child(even){background:#f9f9f9;}
a.back{
    text-decoration:none;
    color:#2c3e50;
    font-weight:bold;
}
</style>
</head>
<body>

<div class="container">
<h2>Contact Messages</h2>
<a href="dashboard.php" class="back">← Back to Dashboard</a>

<table>
<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Message</th>
    <th>Submitted At</th>
</tr>

<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id']; ?></td>
    <td><?= htmlspecialchars($row['name']); ?></td>
    <td><?= htmlspecialchars($row['email']); ?></td>
    <td><?= htmlspecialchars($row['message']); ?></td>
    <td><?= $row['created_at']; ?></td>
</tr>
<?php endwhile; ?>

</table>
</div>

</body>
</html>
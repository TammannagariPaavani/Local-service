<?php
session_start();
include("../backend/db.php");

// Redirect to login if not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin-login.php");
    exit();
}

$servicesList = [];

// Fetch all services
$sql = "SELECT * FROM services ORDER BY id DESC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $servicesList[] = $row;
    }
}

// Counts
$totalServices = count($servicesList);
$totalPending = 0;
$totalApproved = 0;

foreach ($servicesList as $service) {
    if ($service['status'] === 'pending') $totalPending++;
    if ($service['status'] === 'approved') $totalApproved++;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | ServEase</title>

<style>
:root {
    --navy: #032b55;
    --yellow: #ffc107;
    --light-bg: #f4f7fa;
}

body {
    font-family: 'Segoe UI', sans-serif;
    background: var(--light-bg);
    margin: 0;
}

header {
    background: var(--navy);
    color: white;
    padding: 15px 50px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.container {
    max-width: 1200px;
    margin: 30px auto;
    padding: 20px;
}

.stats-row {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: var(--navy);
    color: white;
    flex: 1;
    padding: 40px;
    border-radius: 10px;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

thead {
    background: var(--navy);
    color: white;
}

th, td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

.status-pending { color: orange; font-weight: bold; }
.status-approved { color: green; font-weight: bold; }
.status-rejected { color: red; font-weight: bold; }

.action-btns a {
    padding: 5px 10px;
    margin-right: 5px;
    text-decoration: none;
    border-radius: 4px;
    font-size: 12px;
}

.approve-btn { background: green; color: white; }
.reject-btn { background: red; color: white; }
</style>
</head>

<body>

<header>
    <h1>Admin Dashboard</h1>
    <div>
        <a href="admin-logout.php" style="color: var(--yellow); text-decoration:none;">Logout</a>
    </div>
</header>

<div class="container">

<div class="stats-row">
    <div class="stat-card">
        <h2><?php echo $totalServices; ?></h2>
        <p>Total Services</p>
    </div>

    <div class="stat-card">
        <h2><?php echo $totalApproved; ?></h2>
        <p>Approved</p>
    </div>

    <div class="stat-card">
        <h2><?php echo $totalPending; ?></h2>
        <p>Pending</p>
    </div>
</div>

<table>
<thead>
<tr>
    <th>Service</th>
    <th>Name</th>
    <th>Phone</th>
    <th>City</th>
    <th>Problem Type</th>
    <th>Status</th>
    <th>Actions</th>
</tr>
</thead>

<tbody>
<?php foreach($servicesList as $row): ?>
<tr>
    <td><?php echo htmlspecialchars($row['type']); ?></td>
    <td><?php echo htmlspecialchars($row['name']); ?></td>
    <td><?php echo htmlspecialchars($row['contact']); ?></td>
    <td><?php echo htmlspecialchars($row['city']); ?></td>
    <td><?php echo htmlspecialchars($row['problem_type']); ?></td>

    <td>
        <span class="status-<?php echo $row['status']; ?>">
            <?php echo ucfirst($row['status']); ?>
        </span>
    </td>

    <td class="action-btns">
    <?php if($row['status'] === 'pending'): ?>
        <a class="approve-btn" href="approved.php?id=<?php echo $row['id']; ?>">Approved</a>
        <a class="reject-btn" href="reject.php?id=<?php echo $row['id']; ?>">Reject</a>
    <?php endif; ?>
    <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
    <a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>

</div>
</body>
</html>
<?php
include("../backend/db.php");

if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM services WHERE id=$id");
    $row = $result->fetch_assoc();
}

if(isset($_POST['update'])) {

    $name = $_POST['name'];
    $city = $_POST['city'];
    $contact = $_POST['contact'];

    $sql = "UPDATE services 
            SET name='$name', city='$city', contact='$contact' 
            WHERE id=$id";

    if($conn->query($sql) === TRUE) {
        header("Location: admin-dashboard.php");
        exit();
    } else {
        echo "Update failed";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Service - Admin</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f1f4f9;
        }

        /* Top Navbar */
        .navbar {
            background-color: #1e3a8a;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 20px;
            font-weight: bold;
        }

        /* Center Box */
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 85vh;
        }

        .form-box {
            background: white;
            padding: 30px;
            width: 350px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .form-box h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #1e3a8a;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        button {
            width: 100%;
            padding: 10px;
            background-color: #1e3a8a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background-color: #162d6b;
        }

        .back-btn {
            text-align: center;
            margin-top: 10px;
        }

        .back-btn a {
            text-decoration: none;
            color: #1e3a8a;
            font-size: 14px;
        }
    </style>
</head>
<body>

<div class="navbar">
    Admin Dashboard - Edit Service
</div>

<div class="container">
    <div class="form-box">
        <h2>Edit Service</h2>

        <form method="POST">
            <input type="text" name="name" value="<?php echo $row['name']; ?>" placeholder="Name" required>
            <input type="text" name="city" value="<?php echo $row['city']; ?>" placeholder="City" required>
            <input type="text" name="contact" value="<?php echo $row['contact']; ?>" placeholder="Contact" required>

            <button type="submit" name="update">Update Service</button>
        </form>

        <div class="back-btn">
            <a href="admin-dashboard.php">← Back to Dashboard</a>
        </div>
    </div>
</div>

</body>
</html>